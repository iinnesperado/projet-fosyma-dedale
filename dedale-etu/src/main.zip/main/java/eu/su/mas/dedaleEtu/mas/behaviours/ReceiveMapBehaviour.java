package eu.su.mas.dedaleEtu.mas.behaviours;

import jade.core.behaviours.OneShotBehaviour;

public class ReceiveMapBehaviour extends OneShotBehaviour{

	private static final long serialVersionUID = -1082324081791796312L;

	
	@Override
	public void action() {
		// TODO Auto-generated method stub
		
	}

}
